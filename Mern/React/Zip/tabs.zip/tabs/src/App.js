import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Tab from './Components/Tab';

function App() {

  return (
    <div className="container">
      <div className="jumbotron">
        <Tab />
      </div>
    </div>
  );
}

export default App;